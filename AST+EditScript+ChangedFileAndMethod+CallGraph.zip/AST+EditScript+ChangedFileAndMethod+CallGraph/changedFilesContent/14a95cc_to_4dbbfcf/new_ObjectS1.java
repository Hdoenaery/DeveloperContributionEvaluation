package com.alibaba.fastjson.deserializer.issues3796.bean;





import java.util.List;


public class ObjectS1 {
	
	private int a;

	
	private int b;

	
	private int c = 0;

	
	private int d;

	
	private int e;

	
	private List<ObjectS1_A> f;

	
	private boolean g = false;

	
	private List<ObjectK> h;

	
	private List<ObjectK> i;

	
	private List<ObjectK> j;

	
	private boolean k = true;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public List<ObjectS1_A> getF() {
		return f;
	}

	public void setF(List<ObjectS1_A> f) {
		this.f = f;
	}

	public boolean isG() {
		return g;
	}

	public void setG(boolean g) {
		this.g = g;
	}

	public List<ObjectK> getH() {
		return h;
	}

	public void setH(List<ObjectK> h) {
		this.h = h;
	}

	public List<ObjectK> getI() {
		return i;
	}

	public void setI(List<ObjectK> i) {
		this.i = i;
	}

	public List<ObjectK> getJ() {
		return j;
	}

	public void setJ(List<ObjectK> j) {
		this.j = j;
	}

	public boolean isK() {
		return k;
	}

	public void setK(boolean k) {
		this.k = k;
	}
}
