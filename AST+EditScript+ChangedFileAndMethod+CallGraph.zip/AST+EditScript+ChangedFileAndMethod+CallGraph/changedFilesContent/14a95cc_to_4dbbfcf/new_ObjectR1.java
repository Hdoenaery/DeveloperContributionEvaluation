package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectR1 {
    
    private List<Integer> a;

    
    private int b;

    
    private List<ObjectQ1_A> c;

    private boolean d;

    
    private boolean e;

    
    private int f;

    
    private int g;

    
    private boolean h;

    
    private long i;

    
    private long j;

    
    private List<ObjectM1_A> k;

    public List<Integer> getA() {
        return a;
    }

    public void setA(List<Integer> a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public List<ObjectQ1_A> getC() {
        return c;
    }

    public void setC(List<ObjectQ1_A> c) {
        this.c = c;
    }

    public boolean isD() {
        return d;
    }

    public void setD(boolean d) {
        this.d = d;
    }

    public boolean isE() {
        return e;
    }

    public void setE(boolean e) {
        this.e = e;
    }

    public int getF() {
        return f;
    }

    public void setF(int f) {
        this.f = f;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public boolean isH() {
        return h;
    }

    public void setH(boolean h) {
        this.h = h;
    }

    public long getI() {
        return i;
    }

    public void setI(long i) {
        this.i = i;
    }

    public long getJ() {
        return j;
    }

    public void setJ(long j) {
        this.j = j;
    }

    public List<ObjectM1_A> getK() {
        return k;
    }

    public void setK(List<ObjectM1_A> k) {
        this.k = k;
    }
}
