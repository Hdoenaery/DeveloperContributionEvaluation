package com.alibaba.fastjson.deserializer.issues3796.bean;


public class CommonObject2 {
	
	private int a;
	
	private long b;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public long getB() {
		return b;
	}

	public void setB(long b) {
		this.b = b;
	}
}
