package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectJ1_A {
	
	private int a = 0;
	
	private int b = 0;
	
	private int c = 0;
	
	private int d = 0;
	
	private int e = 0;
	
	private List<CommonObject> f;
	
	private List<ObjectJ1_C> g;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public List<CommonObject> getF() {
		return f;
	}

	public void setF(List<CommonObject> f) {
		this.f = f;
	}

	public List<ObjectJ1_C> getG() {
		return g;
	}

	public void setG(List<ObjectJ1_C> g) {
		this.g = g;
	}
}
