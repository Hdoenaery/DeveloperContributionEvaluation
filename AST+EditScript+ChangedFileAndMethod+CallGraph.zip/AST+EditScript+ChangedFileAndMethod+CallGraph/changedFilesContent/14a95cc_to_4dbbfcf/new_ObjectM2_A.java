package com.alibaba.fastjson.deserializer.issues3796.bean;





public class ObjectM2_A {

    
    private int a;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }
}
