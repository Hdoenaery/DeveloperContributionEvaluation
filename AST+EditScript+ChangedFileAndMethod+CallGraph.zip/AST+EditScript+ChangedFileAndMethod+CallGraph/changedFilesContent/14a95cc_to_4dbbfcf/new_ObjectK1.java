package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectK1 {

	
	private int a = 0;
	
	private boolean b = false;
	
	private int c = 0;
	
	private int d = 0;
	
	private int e = 0;
	
	private List<CommonObject> f;
	
	private List<ObjectK1_A> g;





	
	private int h = 0;
	
	private List<ObjectK1_C> i;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public boolean isB() {
		return b;
	}

	public void setB(boolean b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public List<CommonObject> getF() {
		return f;
	}

	public void setF(List<CommonObject> f) {
		this.f = f;
	}

	public List<ObjectK1_A> getG() {
		return g;
	}

	public void setG(List<ObjectK1_A> g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public List<ObjectK1_C> getI() {
		return i;
	}

	public void setI(List<ObjectK1_C> i) {
		this.i = i;
	}
}
