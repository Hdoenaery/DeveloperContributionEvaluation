package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectL_B {

	
	private int a;
	
	private List<Integer> b;
	
	private List<Integer> c;
	
	private long d;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public List<Integer> getB() {
		return b;
	}

	public void setB(List<Integer> b) {
		this.b = b;
	}

	public List<Integer> getC() {
		return c;
	}

	public void setC(List<Integer> c) {
		this.c = c;
	}

	public long getD() {
		return d;
	}

	public void setD(long d) {
		this.d = d;
	}
}
