package com.alibaba.fastjson.deserializer.issues3796.bean;

public class ObjectO2 {
	
	private int a;

	
	private boolean b = true;

	
	private int c;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public boolean isB() {
		return b;
	}

	public void setB(boolean b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}
}
