package com.alibaba.fastjson.deserializer.issues3796.bean;

import java.util.List;


public class ObjectF2 {

	
	private int a;

	
	private int b;

	
	private List<Integer> c;

	
	private boolean d;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public List<Integer> getC() {
		return c;
	}

	public void setC(List<Integer> c) {
		this.c = c;
	}

	public boolean isD() {
		return d;
	}

	public void setD(boolean d) {
		this.d = d;
	}
}
